<template>
    <div>注册界面
    </div>
</template>

<script>

</script>