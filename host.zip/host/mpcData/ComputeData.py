def checkClientKey(data):
    return None