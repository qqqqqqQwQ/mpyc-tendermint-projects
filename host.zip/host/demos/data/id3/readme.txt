Datasets (number of samples/attributes):

  tennis (14/4): classic textbook example
  balance-scale (625/4): balance scale weight & distance database
  car (1728/6): car evaluation database
  SPECT (267/22): Single Proton Emission Computed Tomography train+test heart images
  KRKPA7 (3196/36): King+Rook versus King+Pawn-on-A7 chess endgame
  tic-tac-toe (958/9): Tic-Tac-Toe endgame
  house-votes-84 (435/16): 1984 US congressional voting records
