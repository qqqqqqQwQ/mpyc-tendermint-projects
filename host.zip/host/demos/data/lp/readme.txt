Datasets (m constraints x n variables):

  0=uvlp (2 x 3): example from AFRICACRYPT 2016 paper on secure verifiable LP
  1=wiki (2 x 3): https://en.wikipedia.org/wiki/Simplex_algorithm#Example
  2=tb2x2 (2 x 2): tiny example
  3=woody (3 x 2): wooden tables & chairs manufacturer classic text book example
  4=LPExample_R20 (20 x 20): small example from SecureSCM project
  5=sc50b (70 x 48): netlib.org/lp/data test problem, obtained via Mathematica
  6=kb2 (68 x 41): netlib.org/lp/data test problem, obtained via Mathematica
  7=LPExample (202 x 288): large example from SecureSCM project
